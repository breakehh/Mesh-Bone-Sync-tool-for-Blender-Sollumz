bl_info = {
    "name": "Mesh & Bone Sync",
    "author": "breakehh_ & Codex",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Mesh & Bone Sync",
    "description": "Moves matching bones after moving the connected mesh",
    "category": "Rigging",
}

import bpy
import bmesh
import re
from mathutils import Vector, Matrix
from bpy.props import PointerProperty, FloatProperty


_BASELINES = {}
_BLENDER_DUPLICATE_SUFFIX = re.compile(r"\.\d{3}$")
_SOLLUMZ_LOD_SUFFIX = re.compile(r"_(?:very_high|high|medium|low|very_low)$", re.IGNORECASE)


def component_name(name):
    name = _BLENDER_DUPLICATE_SUFFIX.sub("", name)
    return _SOLLUMZ_LOD_SUFFIX.sub("", name)


def mesh_component_name(obj):
    data_name = component_name(obj.data.name) if obj.data else ""
    object_name = component_name(obj.name)
    return data_name or object_name

def sibling_lods(obj):
    if obj.parent is None:
        return [obj]
    key = mesh_component_name(obj)
    matches = [
        sibling for sibling in obj.parent.children
        if sibling.type == 'MESH' and mesh_component_name(sibling) == key
    ]
    return matches or [obj]

def linked_to_armature(obj, armature):
    if obj.type != 'MESH':
        return False
    if obj.find_armature() == armature:
        return True
    return any(mod.type == 'ARMATURE' and mod.object == armature for mod in obj.modifiers)


def find_armature(context, meshes):
    configured = context.scene.mesh_bone_sync_armature
    if configured:
        return configured
    candidates = {obj.find_armature() for obj in meshes if obj.find_armature()}
    if len(candidates) == 1:
        return candidates.pop()
    return None


def edit_coordinates(obj):
    if obj.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(obj.data)
        return [vert.co.copy() for vert in bm.verts]
    return [vert.co.copy() for vert in obj.data.vertices]


def matrix_values(matrix):
    return tuple(value for row in matrix for value in row)


def close_matrix(first, second, tolerance):
    return all(abs(a - b) <= tolerance for a, b in zip(first, second))


def selected_edit_meshes(context, armature):
    return [
        obj for obj in context.objects_in_mode
        if obj.type == 'MESH'
    ]


class MESH_BONE_SYNC_OT_capture(bpy.types.Operator):
    bl_idname = "mesh_bone_sync.capture"
    bl_label = "Start tracking"
    bl_description = "nothing here bro, check README !!"
    bl_options = {'REGISTER'}

    def execute(self, context):
        initial_meshes = [obj for obj in context.objects_in_mode if obj.type == 'MESH']
        armature = find_armature(context, initial_meshes)
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "Set Armature, or edit meshes linked to exactly one armature")
            return {'CANCELLED'}

        meshes = selected_edit_meshes(context, armature)
        if not meshes:
            self.report({'ERROR'}, "Enter Edit Mode on the vehicle meshes first")
            return {'CANCELLED'}

        groups = {}
        for obj in meshes:
            groups.setdefault(mesh_component_name(obj), []).append(obj)
        invalid = [name for name, items in groups.items() if not 1 <= len(items) <= 5]
        if invalid:
            self.report({'ERROR'}, "Select every LOD for each component (1-5 copies): %s" %
                        ", ".join(invalid[:4]))
            return {'CANCELLED'}

        selected_pointers = {obj.as_pointer() for obj in meshes}
        missing_lods = {}
        for name, items in groups.items():
            expected = {
                lod.as_pointer(): lod for obj in items for lod in sibling_lods(obj)
            }
            missing = [lod.name for pointer, lod in expected.items() if pointer not in selected_pointers]
            if missing:
                missing_lods[name] = missing
        if missing_lods:
            details = "; ".join(
                "%s: %s" % (name, ", ".join(names))
                for name, names in list(missing_lods.items())[:3]
            )
            self.report({'ERROR'}, "Select every LOD before tracking. Missing: " + details)
            return {'CANCELLED'}

        _BASELINES.clear()
        for obj in meshes:
            _BASELINES[obj.as_pointer()] = {
                "object": obj,
                "name": mesh_component_name(obj),
                "coordinates": edit_coordinates(obj),
                "matrix": matrix_values(obj.matrix_world.copy()),
            }
        context.scene.mesh_bone_sync_armature = armature
        self.report({'INFO'}, "Tracking %d mesh objects. Now move them in Edit Mode." % len(meshes))
        return {'FINISHED'}


class MESH_BONE_SYNC_OT_apply(bpy.types.Operator):
    bl_idname = "mesh_bone_sync.apply"
    bl_label = "Apply location to bone"
    bl_description = "nothing here bro, check README !!"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not _BASELINES:
            self.report({'ERROR'}, "No tracking data. Use 'Start tracking' before editing")
            return {'CANCELLED'}

        armature = context.scene.mesh_bone_sync_armature
        if not armature or armature.type != 'ARMATURE':
            self.report({'ERROR'}, "The tracked armature is no longer available")
            return {'CANCELLED'}

        tolerance = context.scene.mesh_bone_sync_tolerance
        groups = {}
        for record in _BASELINES.values():
            obj = record["object"]
            if not obj or obj.name not in bpy.data.objects:
                self.report({'ERROR'}, "A tracked mesh no longer exists")
                return {'CANCELLED'}
            groups.setdefault(record["name"], []).append(record)

        bone_deltas = {}
        for name, records in groups.items():
            if not 1 <= len(records) <= 5:
                self.report({'ERROR'}, "Incomplete LOD group for '%s' (must contain 1-5 selected LODs)" % name)
                return {'CANCELLED'}
            common_delta = None
            for record in records:
                obj = record["object"]
                if not close_matrix(record["matrix"], matrix_values(obj.matrix_world), tolerance):
                    self.report({'ERROR'}, "Object transform changed: '%s'. Only Edit Mode geometry moves are supported" % obj.name)
                    return {'CANCELLED'}
                before, after = record["coordinates"], edit_coordinates(obj)
                if len(before) != len(after):
                    self.report({'ERROR'}, "Topology changed on '%s'" % obj.name)
                    return {'CANCELLED'}
                if not before:
                    continue
                local_delta = after[0] - before[0]
                for old_co, new_co in zip(before[1:], after[1:]):
                    if (new_co - old_co - local_delta).length > tolerance:
                        self.report({'ERROR'}, "'%s' was not moved as one whole mesh" % obj.name)
                        return {'CANCELLED'}
                world_delta = obj.matrix_world.to_3x3() @ local_delta
                if common_delta is None:
                    common_delta = world_delta
                elif (world_delta - common_delta).length > tolerance:
                    self.report({'ERROR'}, "LOD meshes for '%s' moved by different offsets" % name)
                    return {'CANCELLED'}
            if common_delta is not None and common_delta.length > tolerance:
                bone_deltas[name] = common_delta

        if not bone_deltas:
            self.report({'INFO'}, "No mesh movement to apply")
            _BASELINES.clear()
            return {'FINISHED'}

        previous_active = context.view_layer.objects.active
        previous_selected = list(context.selected_objects)
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='EDIT')
        blocked_connected = []
        try:
            armature_inverse_3x3 = armature.matrix_world.inverted().to_3x3()
            missing = []
            for name, world_delta in bone_deltas.items():
                bone = armature.data.edit_bones.get(name)
                if bone is None:
                    missing.append(name)
                    continue
                if bone.use_connect or any(
                    other.parent == bone and other.use_connect
                    for other in armature.data.edit_bones
                ):
                    blocked_connected.append(name)
            if not blocked_connected:
                stationary_bones = [
                    (bone, bone.head.copy(), bone.tail.copy())
                    for bone in armature.data.edit_bones
                    if bone.name not in bone_deltas
                ]
                for name, world_delta in bone_deltas.items():
                    bone = armature.data.edit_bones.get(name)
                    if bone is None:
                        continue
                    delta = armature_inverse_3x3 @ world_delta
                    bone.head += delta
                    bone.tail += delta
                for bone, original_head, original_tail in stationary_bones:
                    bone.head = original_head
                    bone.tail = original_tail
        finally:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            for obj in previous_selected:
                if obj and obj.name in bpy.data.objects:
                    obj.select_set(True)
            if previous_active and previous_active.name in bpy.data.objects:
                context.view_layer.objects.active = previous_active

        if blocked_connected:
            self.report({'ERROR'}, "Not applied: connected bone(s) could move neighbours: %s" %
                        ", ".join(blocked_connected[:5]))
            return {'CANCELLED'}
        _BASELINES.clear()
        if missing:
            self.report({'WARNING'}, "Applied %d bone(s); no same-named bone: %s" %
                        (len(bone_deltas) - len(missing), ", ".join(missing[:5])))
        else:
            self.report({'INFO'}, "Applied %d location to selected bone(s)" % len(bone_deltas))
        return {'FINISHED'}


class MESH_BONE_SYNC_OT_clear(bpy.types.Operator):
    bl_idname = "mesh_bone_sync.clear"
    bl_label = "Cancel tracking"
    bl_description = "nothing here bro, check README !!"


    def execute(self, context):
        _BASELINES.clear()
        self.report({'INFO'}, "Tracking data cleared")
        return {'FINISHED'}


class MESH_BONE_SYNC_PT_panel(bpy.types.Panel):
    bl_label = "Mesh & Bone Sync"
    bl_idname = "MESH_BONE_SYNC_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mesh & Bone Sync'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.label(text="Vehicle armature")
        layout.prop(scene, "mesh_bone_sync_armature", text="")
        layout.prop(scene, "mesh_bone_sync_tolerance")
        layout.separator()
        layout.operator(MESH_BONE_SYNC_OT_capture.bl_idname, icon='TRACKING')
        layout.operator(MESH_BONE_SYNC_OT_apply.bl_idname, icon='CHECKMARK')
        layout.operator(MESH_BONE_SYNC_OT_clear.bl_idname, icon='X')
        layout.separator()
        row = layout.row(align=True)
        row.label(icon='INFO')
        col = row.column(align=True)
        col.label(text="Select LOD copies")
        col.label(text="and enter Edit Mode.")


classes = (
    MESH_BONE_SYNC_OT_capture,
    MESH_BONE_SYNC_OT_apply,
    MESH_BONE_SYNC_OT_clear,
    MESH_BONE_SYNC_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mesh_bone_sync_armature = PointerProperty(
        name="Vehicle armature", type=bpy.types.Object, poll=lambda self, obj: obj.type == 'ARMATURE')
    bpy.types.Scene.mesh_bone_sync_tolerance = FloatProperty(
        name="Tolerance", default=0.000001, min=0.000001, precision=6,
        description="Maximum allowed difference between LOD movement")


def unregister():
    _BASELINES.clear()
    del bpy.types.Scene.mesh_bone_sync_tolerance
    del bpy.types.Scene.mesh_bone_sync_armature
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
