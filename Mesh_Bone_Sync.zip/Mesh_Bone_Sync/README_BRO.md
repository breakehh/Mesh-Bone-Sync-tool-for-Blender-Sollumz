# Mesh & Bone Sync — Blender 4.5

## How to use it properly with Sollumz and GTA V Vehicles

1. Extract LODs as object (default) via Sollumz
2. Select every existing LOD of the component you want to move.
3. Change to Edit Mode (TAB).
4. Select Vehicle armature.
5. Click on "Start tracking".
6. Select all meshes geometry (A) and move it.
7. Click on "Apply location to bone".
8. Done 

You can move multiple components at once.

## Important

A bone will not be moved when:

- not all existing LODs of that component are selected;
- its LODs were moved by different offsets;
- only part of a mesh was moved, its topology was changed, or Object Mode was used;
- no bone with the matching base name exists.

The sync is one-way: it tracks mesh movement and updates the matching bone. Moving a bone will never move its mesh.

Moving meshes for a parent bone will not move child bones unless the child meshes were also moved.